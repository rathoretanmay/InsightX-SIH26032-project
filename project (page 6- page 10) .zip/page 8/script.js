/* =====================================================
   HARVESTLINK QUEUE SIMULATION
   -----------------------------------------------------
   This is MOCK / DEMO data.

   It does NOT connect to a real depot server.
   Values change visually for hackathon presentation.
   ===================================================== */


/* ================= MOCK QUEUE STATES ================= */

const stateSets = [

    {
        position: "3rd",
        ahead: 3,
        wait: 12,
        active: 4,
        serving: "A-101",
        counter: "Counter #2",
        progress: 70,

        counters: [

            ["Counter 1", "A-099", "Busy"],
            ["Counter 2", "A-101", "Busy"],
            ["Counter 3", "A-102", "Busy"],
            ["Counter 4", "A-103", "Busy"]

        ]
    },


    {
        position: "2nd",
        ahead: 2,
        wait: 8,
        active: 4,
        serving: "A-102",
        counter: "Counter #3",
        progress: 78,

        counters: [

            ["Counter 1", "A-100", "Busy"],
            ["Counter 2", "A-102", "Busy"],
            ["Counter 3", "A-103", "Busy"],
            ["Counter 4", "A-104", "Busy"]

        ]
    },


    {
        position: "2nd",
        ahead: 2,
        wait: 9,
        active: 5,
        serving: "A-102",
        counter: "Counter #3",
        progress: 82,

        counters: [

            ["Counter 1", "A-100", "Busy"],
            ["Counter 2", "A-102", "Busy"],
            ["Counter 3", "A-103", "Busy"],
            ["Counter 4", "A-104", "Busy"],
            ["Counter 5", "Open", "Available"]

        ]
    },


    {
        position: "1st",
        ahead: 1,
        wait: 5,
        active: 5,
        serving: "A-103",
        counter: "Counter #4",
        progress: 90,

        counters: [

            ["Counter 1", "A-101", "Busy"],
            ["Counter 2", "A-102", "Busy"],
            ["Counter 3", "A-103", "Busy"],
            ["Counter 4", "A-104", "Busy"],
            ["Counter 5", "Open", "Available"]

        ]
    }

];


/* ================= CURRENT STATE ================= */

let current = 0;


/* ================= SHORTCUT ================= */

const $ = (id) => {

    return document.getElementById(id);

};


/* ================= RENDER DATA ================= */

function render(data) {


    /* Queue position */

    $("position").textContent =
        data.position;


    $("ahead").textContent =
        data.ahead;


    /* Waiting time */

    $("wait").textContent =
        data.wait;


    /* Active counters */

    $("activeCounters").textContent =
        data.active;


    /* Current serving */

    $("currentServing").textContent =
        data.serving;


    $("currentCounter").textContent =
        data.counter;


    /* Queue progress */

    $("progressPercent").textContent =
        `${data.progress}%`;


    $("progressFill").style.width =
        `${data.progress}%`;


    /* Counter summary */

    $("counterSummary").textContent =
        `${data.active} active`;


    /* Progress message */

    let message;


    if (data.progress >= 90) {

        message =
            "Almost at your turn";

    }

    else if (data.progress >= 80) {

        message =
            "Moving quickly";

    }

    else {

        message =
            "Moving steadily";

    }


    $("progressMessage").textContent =
        message;


    /* ================= COUNTER CARDS ================= */

    $("counterGrid").innerHTML =
        data.counters.map((item, index) => {


            const isFree =
                item[2] === "Available";


            return `

                <article
                    class="counter ${isFree ? "free" : ""}"
                >

                    <div class="counter-number">

                        Station ${index + 1}

                    </div>


                    <div class="counter-title">

                        ${item[0]}

                    </div>


                    <div class="serving">

                        ${
                            isFree
                            ? item[1]
                            : `Serving: ${item[1]}`
                        }

                    </div>


                    <span class="counter-status">

                        ${item[2]}

                    </span>

                </article>

            `;

        }).join("");


    /* ================= UPDATE ANIMATION ================= */

    document
        .querySelectorAll(
            ".stat-card, .progress-card, .counters-card"
        )
        .forEach((element) => {


            element.classList.remove("flash");


            /*
               Force browser to restart
               the animation.
            */

            void element.offsetWidth;


            element.classList.add("flash");

        });

}


/* ================= SYNC CLOCK ================= */

function updateSync() {


    const now =
        new Date();


    $("syncTime").textContent =
        now.toLocaleTimeString(
            [],
            {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: false
            }
        );


    $("syncText").textContent =
        "Simulation synced";

}


/* ================= NEXT QUEUE STEP ================= */

function nextStep() {


    /*
       Move to the next mock state.
    */

    current =
        (current + 1) %
        stateSets.length;


    render(
        stateSets[current]
    );


    updateSync();

}


/* ================= BUTTON ================= */

$("simulateBtn")
    .addEventListener(
        "click",
        nextStep
    );


/* ================= INITIAL LOAD ================= */

render(
    stateSets[current]
);


updateSync();


/* =====================================================
   AUTOMATIC DEMO UPDATE

   Every 5 seconds the mock queue changes.

   IMPORTANT:
   This is only a visual presentation simulation.
   ===================================================== */

setInterval(
    nextStep,
    5000
);