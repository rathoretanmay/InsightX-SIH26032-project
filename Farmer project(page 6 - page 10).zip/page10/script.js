// Mock Data containing different severity levels
const urgentNotices = [
{
  id: 1,
  severity: "critical",
  title: "EMERGENCY: Gate 1 Temporarily Closed",
  desc: "Due to a transport truck breakdown blocking the main entrance, all arriving farmers must route to Gate 3 until further notice. Do not join the Gate 1 queue.",
  time: "Updated 10 mins ago"
},
{
  id: 2,
  severity: "high",
  title: "Heavy Rain Advisory",
  desc: "Severe rain expected at 2:00 PM. Please ensure all grain loads are fully covered with tarpaulins to prevent moisture rejection at the inspection counter.",
  time: "Posted 1 hour ago"
},
{
  id: 3,
  severity: "medium",
  title: "Minor Delays at Weighbridge B",
  desc: "Weighbridge B is undergoing recalibration. Expect an additional 15-minute wait time if assigned to this queue.",
  time: "Posted 3 hours ago"
}];

// DOM Elements
const criticalContainer = document.getElementById("criticalBannerContainer");
const noticesList = document.getElementById("noticesList");
const emptyState = document.getElementById("emptyState");
const loadingState = document.getElementById("loadingState");
const wrapper = document.querySelector(".notices-wrapper");

// Main Render Function
function renderNotices(mode) {
  // Hide UI states before rendering
  emptyState.classList.add("hidden");
  loadingState.classList.add("hidden");
  noticesList.classList.remove("hidden");
  wrapper.classList.remove("hidden");
  
  criticalContainer.innerHTML = "";
  noticesList.innerHTML = "";
  
  // Handle "Clear" Demo State
  if (mode === "clear") {
    wrapper.classList.remove("hidden");
    noticesList.classList.add("hidden");
    emptyState.classList.remove("hidden");
    return;
  }
  
  // Loop through notices and append them based on severity
  urgentNotices.forEach(function(notice) {
    
    // Critical alerts get the big red banner outside the standard list
    if (notice.severity === "critical") {
      const banner = document.createElement("div");
      banner.className = "critical-banner";
      banner.innerHTML = `
                <div class="critical-icon">⚠️</div>
                <div class="critical-content">
                    <h3>${notice.title}</h3>
                    <p>${notice.desc}</p>
                    <p style="margin-top: 8px; font-size: 12px; font-weight: bold;">${notice.time}</p>
                </div>
            `;
      criticalContainer.appendChild(banner);
    }
    // High and Medium alerts go into the standard list
    else {
      const item = document.createElement("div");
      item.className = "notice-item";
      
      // Determine badge class
      const badgeClass = notice.severity === "high" ? "badge-high" : "badge-medium";
      
      item.innerHTML = `
                <div class="notice-header">
                    <span class="severity-badge ${badgeClass}">${notice.severity} Priority</span>
                    <span class="notice-time">${notice.time}</span>
                </div>
                <div class="notice-title">${notice.title}</div>
                <div class="notice-desc">${notice.desc}</div>
            `;
      noticesList.appendChild(item);
    }
  });
}

// Hackathon loading state simulator
function showDemoState(state) {
  criticalContainer.innerHTML = "";
  noticesList.classList.add("hidden");
  emptyState.classList.add("hidden");
  wrapper.classList.remove("hidden");
  
  if (state === "loading") {
    loadingState.classList.remove("hidden");
    
    // Auto-load data after 1 second
    setTimeout(function() {
      renderNotices("all");
    }, 1000);
  }
}

// Initialize on page load
showDemoState("loading");