// Modal UI Interactivity DOM Nodes
const tokenModal = document.getElementById('tokenModal');
const tokenBtn = document.getElementById('tokenBtn');
const closeModalBtn = document.getElementById('closeModalBtn');

// Open QR Modal Screen Handler
if (tokenBtn) {
  tokenBtn.addEventListener('click', () => {
    tokenModal.style.display = 'flex';
  });
}

// Close QR Modal Screen Handler
if (closeModalBtn) {
  closeModalBtn.addEventListener('click', () => {
    tokenModal.style.display = 'none';
  });
}

// Close Modal when tapping outside the dialogue window wrapper
window.addEventListener('click', (event) => {
  if (event.target === tokenModal) {
    tokenModal.style.display = 'none';
  }
});

// Quick Action Click Listener Triggers
const rescheduleBtn = document.getElementById('rescheduleBtn');
if (rescheduleBtn) {
  rescheduleBtn.addEventListener('click', () => {
    alert('Opening procurement appointment rescheduling calendar grid...');
  });
}

const supportBtn = document.getElementById('supportBtn');
if (supportBtn) {
  supportBtn.addEventListener('click', () => {
    alert('Connecting call to the local Mandi Assistance Help Desk Office...');
  });
}

// Sidebar Drawer Interactivity
const menuBtn = document.getElementById('menuBtn');
const sidebarDrawer = document.getElementById('sidebarDrawer');
const closeSidebarBtn = document.getElementById('closeSidebarBtn');
const sidebarOverlay = document.getElementById('sidebarOverlay');

if (menuBtn) {
  menuBtn.addEventListener('click', () => {
    sidebarDrawer.classList.add('open');
    sidebarOverlay.classList.add('active');
  });
}

if (closeSidebarBtn) {
  closeSidebarBtn.addEventListener('click', () => {
    sidebarDrawer.classList.remove('open');
    sidebarOverlay.classList.remove('active');
  });
}

if (sidebarOverlay) {
  sidebarOverlay.addEventListener('click', () => {
    sidebarDrawer.classList.remove('open');
    sidebarOverlay.classList.remove('active');
  });
}

// Live Queue Counter Live Tracker Decrement Simulator
setInterval(() => {
  const queueNumberNode = document.getElementById('queueNum');
  const waitTimeNode = document.getElementById('waitTime');
  
  if (queueNumberNode && waitTimeNode) {
    let currentQueueCount = parseInt(queueNumberNode.textContent, 10);
    
    if (currentQueueCount > 1) {
      currentQueueCount -= 1;
      queueNumberNode.textContent = currentQueueCount.toString().padStart(2, '0');
      waitTimeNode.innerHTML = `<strong>${currentQueueCount * 3} mins</strong>`;
    }
  }
}, 60000); // Re-evaluates queue values once per minute[span_1](start_span)[span_1](end_span)