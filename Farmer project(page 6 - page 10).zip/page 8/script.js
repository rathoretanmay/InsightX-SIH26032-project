// Array of mock queue step objects
const queueSteps = [
    { userToken: "A-104", nowServing: "A-101", position: "3rd", wait: "12 mins", percent: 70 },
    { userToken: "A-104", nowServing: "A-102", position: "2nd", wait: "8 mins", percent: 80 },
    { userToken: "A-104", nowServing: "A-103", position: "1st", wait: "4 mins", percent: 90 },
    { userToken: "A-104", nowServing: "A-104", position: "SERVED", wait: "0 mins", percent: 100 }
];

let stepIndex = 0;

// Updates page DOM elements
function updateScreen() {
    const data = queueSteps[stepIndex];

    document.getElementById("userToken").innerText = data.userToken;
    document.getElementById("nowServing").innerText = data.nowServing;
    document.getElementById("queuePosition").innerText = data.position;
    document.getElementById("waitTime").innerText = data.wait;
    document.getElementById("counter2Token").innerText = "Serving: " + data.nowServing;
    
    document.getElementById("progressPercent").innerText = data.percent + "%";
    document.getElementById("progressBar").style.width = data.percent + "%";

    document.getElementById("syncText").innerText = "Synced: " + new Date().toLocaleTimeString();
}

// Advances step array
function nextStep() {
    stepIndex = (stepIndex + 1) % queueSteps.length;
    updateScreen();
}

// Auto-advance queue state every 5 seconds
setInterval(nextStep, 5000);

// Manual trigger button
document.getElementById("refreshBtn").onclick = nextStep;

// Initialize on page load
updateScreen();
