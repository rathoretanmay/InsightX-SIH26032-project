// Mock Data
const notifications = [
    {
        id: 1,
        type: "slot",
        category: "Slot",
        title: "Delivery Slot Approved",
        desc: "Your intake slot for 21 May at Kampala North Depot is confirmed.",
        time: "10 mins ago",
        read: false
    },
    {
        id: 2,
        type: "queue",
        category: "Queue",
        title: "Your Turn is Coming Up",
        desc: "Token A-104 is now 3rd in position at Inspection Counter #2.",
        time: "25 mins ago",
        read: false
    },
    {
        id: 3,
        type: "payment",
        category: "Payment",
        title: "Payout Initiated",
        desc: "UGX 1,248,000 transfer sent for Load HL-240521-084.",
        time: "2 hours ago",
        read: true
    },
    {
        id: 4,
        type: "notice",
        category: "Notice",
        title: "Depot Maintenance Schedule",
        desc: "Gate 3 will close early today at 4:00 PM for equipment service.",
        time: "1 day ago",
        read: true
    }
];

let currentFilter = "all";

// Elements
const list = document.getElementById("notificationList");
const loadingState = document.getElementById("loadingState");
const errorState = document.getElementById("errorState");
const emptyState = document.getElementById("emptyState");
const syncText = document.getElementById("syncText");
const syncDot = document.getElementById("syncDot");

// Render List
function render() {
    list.innerHTML = "";
    
    const filtered = notifications.filter(function(item) {
        return currentFilter === "all" || item.type === currentFilter;
    });

    if (filtered.length === 0) {
        showDemoState("empty");
        return;
    }

    filtered.forEach(function(item) {
        const div = document.createElement("div");
        div.className = "notification-item " + (item.read ? "" : "unread");
        div.innerHTML = `
            <div class="item-left">
                <span class="item-tag">${item.category}</span>
                <div class="item-title">${item.title}</div>
                <div class="item-desc">${item.desc}</div>
            </div>
            <div class="item-time">${item.time}</div>
        `;
        list.appendChild(div);
    });
}

// Filter Clicks
document.querySelectorAll(".filter-btn").forEach(function(btn) {
    btn.onclick = function(e) {
        document.querySelectorAll(".filter-btn").forEach(function(b) {
            b.classList.remove("active");
        });
        e.target.classList.add("active");
        currentFilter = e.target.getAttribute("data-filter");
        render();
    };
});

// Mark All Read
document.getElementById("markAllReadBtn").onclick = function() {
    notifications.forEach(function(n) {
        n.read = true;
    });
    render();
};

// Retry Button
document.getElementById("retryBtn").onclick = function() {
    showDemoState("loading");
    setTimeout(function() {
        showDemoState("success");
    }, 1000);
};

// State Switcher for Demo
function showDemoState(state) {
    loadingState.classList.add("hidden");
    errorState.classList.add("hidden");
    emptyState.classList.add("hidden");
    list.classList.add("hidden");
    syncDot.classList.remove("error");

    if (state === "loading") {
        loadingState.classList.remove("hidden");
        syncText.innerText = "Syncing...";
    } else if (state === "error") {
        errorState.classList.remove("hidden");
        syncDot.classList.add("error");
        syncText.innerText = "Sync Failed";
    } else if (state === "empty") {
        emptyState.classList.remove("hidden");
        syncText.innerText = "Synced: " + new Date().toLocaleTimeString();
    } else {
        list.classList.remove("hidden");
        syncText.innerText = "Synced: " + new Date().toLocaleTimeString();
        render();
    }
}

// Init
setTimeout(function() {
    showDemoState("success");
}, 600);
