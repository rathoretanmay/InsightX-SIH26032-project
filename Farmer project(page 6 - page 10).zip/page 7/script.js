// --- Interactive Map Initialization (Leaflet.js) ---
const map = L.map('map').setView([28.6139, 77.2090], 12); // Center map coordinates

// Load OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Define Centre markers array
const centresData = [
    { name: "North Gate Mandi Yard", lat: 28.6200, lng: 77.2100, address: "Sector 14, Main Highway" },
    { name: "East District Grain Market", lat: 28.6050, lng: 77.2300, address: "Bypass Road, Grain Silos" }
];

const markers = {};

// Add markers to the map
centresData.forEach(centre => {
    const marker = L.marker([centre.lat, centre.lng])
        .addTo(map)
        .bindPopup(`<b>${centre.name}</b><br>${centre.address}`);
    markers[centre.name] = marker;
});


// --- Search & Filter Logic Module ---
const searchInput = document.getElementById('searchInput');
const centreCards = document.querySelectorAll('.centre-card');
const noResultsState = document.getElementById('noResultsState');

searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    let visibleCount = 0;
    
    centreCards.forEach(card => {
        if (card.textContent.toLowerCase().includes(term)) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    noResultsState.style.display = visibleCount === 0 ? 'block' : 'none';
});

// Category Filter Button Logic
const filterBtns = document.querySelectorAll('.filter-btn');
filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.getAttribute('data-filter');
        let visibleCount = 0;
        
        centreCards.forEach(card => {
            const category = card.getAttribute('data-category');
            if (filter === 'all' || category.includes(filter)) {
                card.style.display = 'block';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });
        
        noResultsState.style.display = visibleCount === 0 ? 'block' : 'none';
    });
});

// Centre Selection Handler (Pans map to selected centre)
const selectButtons = document.querySelectorAll('.select-btn');
selectButtons.forEach(button => {
    button.addEventListener('click', () => {
        const centreName = button.getAttribute('data-centre');
        const lat = parseFloat(button.getAttribute('data-lat'));
        const lng = parseFloat(button.getAttribute('data-lng'));
        
        // Pan and zoom map to the selected centre pin
        map.setView([lat, lng], 15);
        if (markers[centreName]) {
            markers[centreName].openPopup();
        }
        
        alert(`Successfully booked slot at: ${centreName}`);
    });
});

// Location Permission Banner Toggle
const enableLocationBtn = document.getElementById('enableLocationBtn');
const permissionBanner = document.getElementById('permissionBanner');

enableLocationBtn.addEventListener('click', () => {
    permissionBanner.style.display = 'none';
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;
            
            // Add a user location marker and center map
            L.marker([userLat, userLng], {
                icon: L.divIcon({ className: 'user-location-pin', html: '📍', iconSize: [24, 24] })
            }).addTo(map).bindPopup("You are here").openPopup();
            
            map.setView([userLat, userLng], 13);
            alert('Location permission granted! Map centered to your location.');
        }, () => {
            alert('Unable to retrieve your location via browser.');
        });
    } else {
        alert('Geolocation is not supported by your browser.');
    }
});